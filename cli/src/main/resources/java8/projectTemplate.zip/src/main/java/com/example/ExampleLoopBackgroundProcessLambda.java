package com.example;

import io.electrica.pipeline.java8.spi.LoopBackgroundProcessLambda;
import io.electrica.sdk.java8.api.Connection;
import io.electrica.sdk.java8.api.Connector;
import io.electrica.sdk.java8.api.Electrica;
import io.electrica.sdk.java8.echo.test.v1.EchoTestV1;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Slf4j
public class ExampleLoopBackgroundProcessLambda extends LoopBackgroundProcessLambda {

    private EchoTestV1 echoTest;

    @Override
    public String getName() {
        return "LoopBackgroundProcessLambda";
    }

    @Override
    public void initialize(Electrica electrica) throws Exception {
        super.initialize(electrica);

        Connector connector = electrica.connector(EchoTestV1.ERN);
        Connection connection = connector.defaultConnection();
        echoTest = new EchoTestV1(connection);
    }

    @Override
    protected long getSleepInterval() {
        return TimeUnit.DAYS.toMillis(1);
    }

    @Override
    protected boolean doInLoop() {
        // Ping backend once a day
        try {
            echoTest.ping();
            log.info("Server is up");
        } catch (Exception e) {
            log.error("Server is down");
        }
        return true;
    }

    @Override
    public void destroy(Electrica electrica) throws Exception {
        super.destroy(electrica);

        echoTest.close();
    }
}
