package com.example;

import com.google.auto.service.AutoService;
import io.electrica.pipeline.java8.spi.Lambda;
import io.electrica.sdk.java8.api.Connection;
import io.electrica.sdk.java8.api.Connector;
import io.electrica.sdk.java8.api.Electrica;
import io.electrica.sdk.java8.echo.test.v1.EchoTestV1;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;
import java.util.concurrent.CountDownLatch;

@Slf4j
@AutoService(Lambda.class)
public class EchoLambda implements Lambda {

    private final CountDownLatch stopLatch = new CountDownLatch(1);

    private Connection connection;
    private UUID listenerId;

    @Override
    public String getName() {
        return "echo-lambda-name";
    }

    @Override
    public void onStopSignal() throws Exception {
        // Gracefully stop main thread releasing the thread from `doWork` method
        stopLatch.countDown();
    }

    @Override
    public void started(Electrica electrica) throws Exception {
        Connector connector = electrica.connector(EchoTestV1.ERN);
        connection = connector.defaultConnection();

        // Listen to messages from webhook
        listenerId = connection.addMessageListener(__ -> true, message -> {
            EchoTestV1 echoTest = new EchoTestV1(connection);
            try {
                String payload = message.getPayload();
                return echoTest.echo(payload);
            } catch (Exception e) {
                log.error("Something went wrong handling message: " + message.getId(), e);
                return null;
            }
        });
    }

    /**
     * Await lambda termination in main thread to keep listen webhook messages
     */
    @Override
    public void doWork(Electrica electrica) throws Exception {
        stopLatch.await();
    }

    @Override
    public void beforeStop(Electrica electrica) throws Exception {
        connection.removeMessageListener(listenerId);
    }
}
